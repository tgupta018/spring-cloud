package com.demo.ds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoDiscoveryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoDiscoveryServerApplication.class, args);
	}

}
