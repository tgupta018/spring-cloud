package com.example.demopersonapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoPersonAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoPersonAppApplication.class, args);
	}

}
